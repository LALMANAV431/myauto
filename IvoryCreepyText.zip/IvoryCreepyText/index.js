require("dotenv").config();
const TronWeb = require("tronweb");

// Setup TronWeb
const tronWeb = new TronWeb({
  fullHost: "https://api.trongrid.io",
  privateKey: process.env.PRIVATE_KEY,
});

// Address to send TRX to
const RECEIVER = process.env.RECEIVER_ADDRESS;

let lastBalance = 0;

async function checkAndTransfer() {
  try {
    const sender = await tronWeb.defaultAddress.base58;
    const balance = await tronWeb.trx.getBalance(sender); // in SUN (1 TRX = 1,000,000 SUN)

    console.log("Current Balance:", balance / 1_000_000, "TRX");

    // If new TRX received
    if (balance > lastBalance && balance > 10000) { // more than 0.01 TRX
      const tx = await tronWeb.trx.sendTransaction(RECEIVER, balance - 10000); // keep 0.01 TRX to avoid empty wallet
      console.log("Transferred to", RECEIVER, "=> TXID:", tx.txid);
      lastBalance = await tronWeb.trx.getBalance(sender);
    }
  } catch (err) {
    console.error("Error:", err);
  }
}

// Check every 2 seconds
setInterval(checkAndTransfer, 2000);